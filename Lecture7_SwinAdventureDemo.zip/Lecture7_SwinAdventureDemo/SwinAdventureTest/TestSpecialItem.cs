using System;
using SwinAdventure;

public class TestSpecialItem
{
    private SpecialItem _item;

    [SetUp]
    public void Setup()
    {
        _item = new SpecialItem(new string[] { "commands", "objects", "7710" }, "name", "description", "something");
    }

    [Test]
    public void TestShortDescription()
    {
        Assert.That(_item.Specialty, Is.EqualTo("something"));
    }
    
    [Test]
    public void RandomItemTest()
    {
        _item.Specialty = "random";
        Assert.That(_item.Specialty, Is.EqualTo("random"));
    }
}
using System;
using SwinAdventure;

public class LookCommandTest
{
    private Item _testItem;
    private Player _testPlayer;
    private Bag _testMoneyBag;
    private Bag _testGemBag;
    private LookCommand _testLookCommand;

    [SetUp]
    public void Setup()
    {
        _testLookCommand = new LookCommand(new string[] { "" });
        _testPlayer = new Player("HarryPotter", "a student");

        _testItem = new Item(new string[] { "gem", "Ruby" }, "A Ruby", "A bright Pink ruby");
        _testMoneyBag = new Bag(new string[] { "bag", "money" }, "Money Bag", "A bag that contains Money");
        _testGemBag = new Bag(new string[] {"bag", "gems" }, "Gems Bag", "A bag that contains Gems");

        _testPlayer.Inventory.Put(_testItem);
    }
    
    [Test]
    public void LookAtPlayer()
    {
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "at", "inventory"}), Is.EqualTo("You are HarryPotter a student\nYou are carrying:\nA Ruby (gem)"));
    }
    
    [Test]
    public void LookAtItem()
    {
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "at", "gem"}), Is.EqualTo("A bright Pink ruby"));
    }
    
    [Test]
    public void LookAtNothing()
    {
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "at", "Jade"}), Is.EqualTo("The Itemjade is not available"));
    }
    
    [Test]
    public void LookAtItemInPlayer()
    {
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "at", "gem", "in", "inventory"}), Is.EqualTo("A bright Pink ruby"));
    }

    [Test]
    public void LookAtItemInBag()
    {
        _testPlayer.Inventory.Put(_testMoneyBag); //The player now have the Money Bag in the player inventory.
        _testMoneyBag.Inventory.Put(_testItem); //The Money Bag in the player inventory now contain an item.
        Assert.That(_testLookCommand.Execute(_testPlayer, ["Look", "at", "gem", "in", "bag"]) == _testItem.FullDescription); //Since the player inventory have the bag and the item in that bag, thus the player can look at, find it and return the item full description.
    }
    
    [Test]
    public void LookAtItemInNoBag()
    { 
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "at", "gem", "in", "Gems Bag"}), Is.EqualTo("I can't find theGems Bag"));
    } //The player looking at an item in a non exit bag (Gems bag) because I haven't put the function (_testPlayer.Inventory.Put(_testGemBag)) yet.
    
    [Test]
    public void LookAtNothingInBag()
    {
        _testPlayer.Inventory.Put(_testMoneyBag); //Player inventory will now only have Money Bag.
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "at", "gem", "in", "Money Bag"}), Is.EqualTo("I can't find theMoney Bag"));
    } //The player can't find the item despite having the bag in it inventory because I haven't put a function so that the Money Bag have the item that the player looking for inside that bag,(_testMoneyBag.Inventory.Put(_testItem).
    
    [Test]
    public void InvalidLook()
    {
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "around"}), Is.EqualTo("I don't know how to look like that"));
        
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"hello", "104697710"}), Is.EqualTo("I don't know how to look like that"));
        
        Assert.That(_testLookCommand.Execute(_testPlayer, new string[] {"Look", "at", "your", "name"}), Is.EqualTo("I don't know how to look like that"));
    }
}
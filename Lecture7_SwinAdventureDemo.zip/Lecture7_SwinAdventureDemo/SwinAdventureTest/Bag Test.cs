using SwinAdventure;
using System;

public class BagTest
{
    private Bag _testFoodBag;
    private Bag _testSchoolBag;
    private Item _testItem1;
    private Item _testItem2;

    [SetUp]
    public void Setup()
    {
        _testFoodBag = new Bag(new string[] { "bag", "food" }, "Food Bag", "A bag containing food");
        _testSchoolBag = new Bag(new string[] { "bag", "school" }, "School Bag", "A bag for School");

        _testItem1 = new Item(new string[] { "red", "orange" }, "orange red", "red for final test");
        _testItem2 = new Item(new string[] { "pencil", "yellow" }, "pencil yellow", "pencil yellow from home");

        _testFoodBag.Inventory.Put(_testItem1);
        _testSchoolBag.Inventory.Put(_testItem2);
        
        _testFoodBag.Inventory.Put(_testSchoolBag);
    }

    [Test]
    public void BagLocatesItem()
    {
        Assert.That(_testSchoolBag.Locate("pencil"), Is.EqualTo(_testItem2));
        Assert.That(_testSchoolBag.Locate("yellow"), Is.EqualTo(_testItem2));
        Assert.That(_testFoodBag.Locate("red"), Is.EqualTo(_testItem1));
        Assert.That(_testFoodBag.Locate("orange"), Is.EqualTo(_testItem1));
    }

    [Test]
    public void BagLocatesItSelf()
    {
        Assert.That(_testSchoolBag.Locate("school"), Is.EqualTo(_testSchoolBag));
        Assert.That(_testFoodBag.Locate("food"), Is.EqualTo(_testFoodBag));
    }

    [Test]
    public void BagLocatesNothing()
    {
        Assert.That(_testSchoolBag.Locate("red"), Is.EqualTo(null));
    }

    [Test]
    public void BagFullDescription()
    {
        Assert.That(_testFoodBag.FullDescription, Is.EqualTo("In the Food Bag you can see:\norange red (red),School Bag (bag)"));
    }

    [Test]
    public void BagInBag()
    {
        Assert.That(_testFoodBag.Locate("school"), Is.EqualTo(_testSchoolBag));
        Assert.That(_testFoodBag.Locate("red"), Is.EqualTo(_testItem1));
        Assert.That(_testFoodBag.Locate("yellow"), Is.Null);
    }

    [Test]
    public void BagPrivelegeItem()
    {
        _testItem2.PrivilegeEscalation("7710");
        Assert.That(_testFoodBag.Locate("COS20007"), Is.EqualTo(null));
    }
}
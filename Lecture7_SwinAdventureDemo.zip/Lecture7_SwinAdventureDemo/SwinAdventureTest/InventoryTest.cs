using NUnit.Framework.Legacy;
using SwinAdventure;

public class InventoryTest
{
        private Inventory _testInventory;
        private Item _testItem1;
        private Item _testItem2;
        private Item _testItem3;

        [SetUp]
        public void Setup()
        {
            _testInventory = new Inventory();

            _testItem1 = new Item(new string[] { "silver", "hat" }, "A Bronze Sword", "A very sharp bronze sword");
            _testItem2 = new Item(new string[] { "light", "torch" }, "A Torch", "A Torch to light the path");
            _testItem3 = new Item(new string[] {"gun", "bullets"}, "A gun", "A gun to shoot bullets");

            _testInventory.Put(_testItem1);
            _testInventory.Put(_testItem2);
            _testInventory.Put(_testItem3);
        }

        [Test]
        public void HasItemTest()
        {
            Assert.That(_testInventory.HasItem("silver"), Is.True);
            Assert.That(_testInventory.HasItem("hat"), Is.True);
            Assert.That(_testInventory.HasItem("light"), Is.True);
            Assert.That(_testInventory.HasItem("torch"), Is.True);
            Assert.That(_testInventory.HasItem("gun"), Is.True);
            Assert.That(_testInventory.HasItem("bullets"), Is.True);
        }

        [Test]
        public void DosentHaveItemTest()
        {
            Assert.That(_testInventory.HasItem("coconut"),  Is.False);
        }

        [Test]
        public void FetchItemTest()
        {
            Item fetched = _testInventory.Fetch("hat");
            Assert.That(fetched, Is.EqualTo(_testItem1));
            Assert.That(_testInventory.HasItem("hat"), Is.True);
        }

        [Test]
        public void TakeItemTest()
        {
            Item taken = _testInventory.Fetch("hat");
            Assert.That(taken, Is.EqualTo(_testItem1));
            Assert.That(_testInventory.HasItem("hat"), Is.True);
        }

        [Test]
        public void ListItemTest()
        {
            Assert.That(_testInventory.ItemList, Is.EqualTo("A Bronze Sword (silver),A Torch (light),A gun (gun)"));
        }
}
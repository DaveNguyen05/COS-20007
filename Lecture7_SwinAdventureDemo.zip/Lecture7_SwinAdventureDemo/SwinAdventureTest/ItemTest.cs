using SwinAdventure;

public class ItemTest
{
    private Item _testItem1;
    private Item _testItem2;
    private Item _testItem3;

    [SetUp]
    public void Setup()
    {
        _testItem1 = new Item(new string[] { "silver", "hat" }, "A Silver Hat", "A very shiny silver hat");
        _testItem2 = new Item(new string[] { "light", "torch" }, "A Torch", "A Torch to light the path");
        _testItem3 = new Item(new string[] { "gun", "bullets" }, "A Gun", "A gun to shoot bullets");
    }

    [Test]
    public void IdentifiableItem()
    {
        Assert.That(_testItem1.AreYou("silver"), Is.True);
        Assert.That(_testItem1.AreYou("hat"), Is.True);
        Assert.That(_testItem2.AreYou("light"), Is.True);
    }

    [Test]
    public void ItemShortDescription()
    {
        Assert.That(_testItem3.ShortDescription, Is.EqualTo("A Gun (gun)"));
    }

    [Test]
    public void ItemFullDescription()
    {
        Assert.That(_testItem3.FullDescription, Is.EqualTo("A gun to shoot bullets"));
    }
}

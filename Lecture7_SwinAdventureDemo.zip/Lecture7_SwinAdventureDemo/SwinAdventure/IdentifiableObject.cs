using System;
using System.Collections.Generic;

namespace SwinAdventure
{
    public class IdentifiableObject
    {
        private List<string> _identifiers;

        public string FirstId
        {
            get
            {
                if (_identifiers.Count > 0)
                    return _identifiers[0];
                return "";
            }
        }

        public IdentifiableObject(string[] idents)
        {
            _identifiers = new List<string>();
            foreach (String ident in idents)
            {
                AddIdentifier(ident);
            }
        }

        public void AddIdentifier(string id)
        {
            _identifiers.Add(id.ToLower());
        }

        public bool AreYou(string id)
        {
             return _identifiers.Contains(id.ToLower()) ;
        }

        public void PrivilegeEscalation(string pin) //Only one parameter (string pin) and the PE works: declare a string contain the desired pin, if the pin is entered correctly and the idents is larger than 0 then the first idents will equal to the output stated, in this case its "COS20007"
        {
            string lastFourDigits = "7710";
            if (pin == lastFourDigits && _identifiers.Count > 0)
            {
                _identifiers[0] = "COS20007";
            }
        }
    }
}

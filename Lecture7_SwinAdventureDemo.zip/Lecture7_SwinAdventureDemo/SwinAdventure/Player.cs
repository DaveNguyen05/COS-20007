using System;
namespace SwinAdventure
{
    public class Player : GameObject,  IHaveInventory //Polymorphism.
    {
        private Inventory _inventory;
        private Location _location;
        public Player(string name, string desc) : base(new string[] { "me", "inventory" }, name, desc)
        {
            _inventory = new Inventory();
        }
        public Inventory Inventory
        {
            get {
                return _inventory;
            }
        }

        public Location Location
        {
            get 
            {
                return _location;
            }
            set
            {
                _location = value; //set the location to any value desired.
            }
        }

        public GameObject Locate(string id)
        {
            if (AreYou(id))
            {
                return this;
            }
            else
            {
                Item obj = Inventory.Fetch(id); //To check if they generated from "inventory.Fetch".
                if (obj == null && Location != null) //to check if the object is null and the location of the player is not null,
                {                                    //if it's not null then we can ask the current location 
                    return Location.Locate(id); 
                }
                return obj; //return object directly if the object is in the inventory,
            }              //if not then it will try to go to the 'locate' method of the current location of the player.
        }
        public override string FullDescription
        {
            get
            {
                return $"You are {Name} {base.FullDescription}\n" + "You are carrying:\n" + _inventory.ItemList;
            }
        }

        public override void SaveTo(StreamWriter writer){
                base.SaveTo(writer);
                writer.WriteLine(_inventory.ItemList);
        }

        public override void LoadFrom(StreamReader reader){
                base.LoadFrom(reader);
                string ItemDescriptionList =  reader.ReadLine();

                //display the information to Console
                Console.WriteLine("Player information");
                Console.WriteLine(Name);
                Console.WriteLine(ShortDescription);
                Console.WriteLine(ItemDescriptionList);
        }
    }
}

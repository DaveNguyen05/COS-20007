﻿using System;
using SwinAdventure;
 
namespace MainProgram
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("What is your name?");
            string playerName = Console.ReadLine();
            Console.WriteLine("Tell me about you");
            string playerDescription = Console.ReadLine();
            Player _testPlayer;
            _testPlayer = new Player("James", "an explorer");

            Item item1 = new Item(new string[] { "silver", "hat" }, "A Silver Hat", "A very shiny silver hat");
            Item item2 = new Item(new string[] { "light", "torch" }, "A Torch", "A Torch to light the path");
            Item item3 = new Item(new string[] { "gun", "bullets" }, "A Gun", "A Gun to shoot bullets");
            Item item4 = new Item(new string[] { "bag", "fish" }, "A Fish Bag", "A Bag containing Fish");
            _testPlayer.Inventory.Put(item1);
            _testPlayer.Inventory.Put(item2);
            _testPlayer.Inventory.Put(item3);
            _testPlayer.Inventory.Put(item4);
            bool finished = false;
            LookCommand cmd = new LookCommand(new string[] {""});
            while (!finished)
            {
                Console.WriteLine("Enter a command");
                string command = Console.ReadLine();
                if (command.ToLower() == "exit")
                {
                    finished = true;
                    break;
                }
                //string[] commandArray = command.Split(" ");

                //if (commandArray[0].ToLower() == "move")
                //{
                    //cmd = new MoveCommand(new string[] {""});
                //}
                string[] commandArray = command.Split(" ");
                Console.WriteLine(cmd.Execute(_testPlayer, commandArray));
            }

            //Print the player Identifiers
            Console.WriteLine(_testPlayer.AreYou("me"));
            Console.WriteLine(_testPlayer.AreYou("inventory"));

            if(_testPlayer.Locate("torch") !=null){
                Console.WriteLine("The object torch exists");
                Console.WriteLine(_testPlayer.Inventory.HasItem("torch"));
            } else{
                Console.WriteLine("The object torch does not exist");
            }

            Player _testPlayer2 = new Player("James", "an explorer"); //Declare "_testPlayer2" so that it can work.
            
            List<IHaveInventory> myContainers = new List<IHaveInventory>();
            myContainers.Add(_testPlayer2);

            //define a bag object and an item, then add the item into the inventory of the bag.
            Bag _testToolBag;
            _testToolBag = new Bag(new string[] { "bag", "tool" }, "Tools Bag", "A bag that contains tools");
            Item _testItem2;
            _testItem2 = new Item(new string[] { "stew", "beef" }, "A Beef Stew", "A hearty beef stew");
            _testToolBag.Inventory.Put(_testItem2);
            Bag _testFishBag;
            _testFishBag = new Bag(new string[] { "bag", "fish" }, "Fishing Bag", "A fishing bag");
            Item _testItem3;
            _testItem3 = new Item(new string[] { "raw", "fish" }, "A Raw Raw", "A Raw Fish");
            _testPlayer2.Inventory.Put(_testItem3);
            myContainers.Add(_testToolBag); //"myContainers" is a collection that stores different types of objects that can hold items in their inventory.
            myContainers.Add(_testFishBag); //Containers hold 'Player' and 'Bag' objects.
            
            foreach (IHaveInventory container in myContainers)
            {
                if (container is Bag)
                {
                    Bag currentBag = (Bag)container;
                    Console.WriteLine(currentBag.Name); //Display the name of bags
                    Console.WriteLine(currentBag.FullDescription);
                }
                else if (container is Player)
                {
                    Player currentPlayer = (Player)container;
                    Console.WriteLine(currentPlayer.Name); //Display the names of players
                    Console.WriteLine(currentPlayer.FullDescription);
                }
            }

            //write the PlayerObject to file
            StreamWriter writer = new StreamWriter("TestPlayer.txt");
            try {
                _testPlayer.SaveTo(writer);
            }
            finally
            {
                writer.Close();
            }
            
            //read from the file
            StreamReader reader = new StreamReader("TestPlayer.txt");
            try {
                _testPlayer.LoadFrom(reader);
            }
            finally
            {
                writer.Close();
            }
        }
    }
}

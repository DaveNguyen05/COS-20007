using System;

namespace SwinAdventure
{
    public abstract class Command : IdentifiableObject //inherited from IdentifiableObject class
    {
        public Command(string[] ids) : base(ids) 
        {
        }
        
        public abstract string Execute(Player p, string[] text);
    }
}


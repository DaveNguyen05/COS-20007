using System;
namespace SwinAdventure
{
    public class Location : GameObject, IHaveInventory
    {
        private Inventory _inventory;
        private List<Path> _paths = [];
        public Location(string[] ids, string name, string desc) : base(ids, name, desc)
        {
            _inventory = new Inventory(); //creating new inventory.
            _paths = new List<Path>(); //contain list of paths.
        }
        public GameObject Locate(string id) //returning a game object.
        {
            if (AreYou(id)) //if it exits within the identifiers, 'return this' "this" is a special keyword in C#
            {               //to highlight current object that it instance inherited from the class (in this case it's Inventory class).
                return this;
            }
            else //if not, return from the inventory and fetch it from the exiting id.
            {
                return _inventory.Fetch(id);
            }
        }
        public void AddPath(Path path)
        {
            _paths.Add(path); //adding paths
        }
        //develop to fetch and return an exiting path given input parameter is the path id.
        //and create a for loop to check the AreYou method of each path.
        public Path Fetch(string id)
        {
            if (AreYou(id))
            {
                return _paths[0];
            }
            else
            {
                return null;
            }
        }
        public override string FullDescription //writing as property so we don't need the '()'
        {
            get
            {
                string nameDescription; //"nameDescription" later on will be used to specify for the name of the current location.
                string inventoryDescription;
                if (Name != null && Name != "") //check to see the name is null or not null.
                {
                    nameDescription = Name;
                }
                else //otherwise, default statement
                {
                    nameDescription = "an unknown location";
                }

                if (_inventory != null && _inventory.ItemList != null) //further check on the inventory to see if it's not null
                {                                                     //and have the item list inside.
                    inventoryDescription = _inventory.ItemList;
                }
                else
                {
                    inventoryDescription = "there are no items in the location. ";
                }
                return "You are in " + nameDescription + ". " + base.FullDescription + "\n Here, you can see :\n" + inventoryDescription;
            } //if all the information is correct, this will be the return information.
        }
    }
}


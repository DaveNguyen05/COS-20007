using System;
namespace SwinAdventure
{
    public interface IHaveInventory
    {
        GameObject Locate(string id); // To ensure that whatever class implemented in this interface can override the "Locate" method (Polumophism).
        string Name { get; }
    }
}
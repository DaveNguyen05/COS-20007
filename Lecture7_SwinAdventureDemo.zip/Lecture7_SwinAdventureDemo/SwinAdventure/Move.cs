using System;
namespace SwinAdventure
{
    public class MoveCommand : Command
    {
        public MoveCommand() : base(new string[] { "move", "go", "head", "leave" })
        {
        }

        public override string Execute(Player p, string[] text)
        {
            // Check for valid command format
            if (text.Length != 2)
            {
                return "Where do you want to go?";
            }

            // Check if text[0] is the command
            if (text[0].ToLower() != "move" && text[0].ToLower() != "go" && 
                text[0].ToLower() != "head" && text[0].ToLower() != "leave")
            {
                return "Error in move command.";
            }

            // Get the direction from the second word
            string direction = text[1].ToLower();

            // Try to find the path in the current location
            Path path = p.Location.Locate(direction) as Path;

            if (path == null)
            {
                return "You cannot go in that direction.";
            }

            // Move the player using the path
            return path.MovePlayer(p);
        }
    }
}


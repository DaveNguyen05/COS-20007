using System;
namespace SwinAdventure
{
   public class Bag : Item,  IHaveInventory // The "Bag" already have the locate method = no more work needed.
                                             //Bag is a child class of Item and Inventory.
   {
      private Inventory _inventory;
      public Bag(string[] ids, string name, string desc) : base(ids, name, desc)
      {
         _inventory = new Inventory();
      }

      public GameObject Locate(string id)
      {
         if (AreYou(id))
         {
            return this; //"this" return current object which is the Bag Object *(Final Test might ask about keywords)*
         }
         else if (_inventory.HasItem(id))
         {
            return _inventory.Fetch(id); //"Fetch" instead of 'Take' is because we don't want to remove the item.
         }
         else
         {
            return null;
         }
      }

      public Inventory Inventory
      {
         get { return _inventory; }
      }

      public override string FullDescription
      {
         get { return "In the " + Name + " you can see:\n" + Inventory.ItemList; }
      }
   }
}
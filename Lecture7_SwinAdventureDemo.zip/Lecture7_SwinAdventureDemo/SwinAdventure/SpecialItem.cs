using System;

namespace SwinAdventure
{
    public class SpecialItem : GameObject
    {
        private string _specialty;
        public SpecialItem(string[] idents, string name, string desc, string specialty) : base(idents, name, desc)
        {
            _specialty = specialty;
        }

        public string Specialty
        {
            get { return _specialty; }
            set { this._specialty = value; }
        }
    }
}
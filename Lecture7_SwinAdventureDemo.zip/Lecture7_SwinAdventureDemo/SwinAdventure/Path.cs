using System;

namespace SwinAdventure
{
    public class Path : GameObject //the path only have one destination in the direction of the path.
    {
        private Location _destination;
        public Path(string[] ids, string name, string description, Location destination) : base(ids, name, description) //triggered the base of the game object.
        {
            _destination = destination; //decide the location of the path to be the input parameter (destination). 
        }

        public Location Destination
        {
            get
            {
                return _destination; //return the current destination.
            }
        }
        
        public string MovePlayer(Player p)
        {
            if (_destination == null) //check if the path has a valid destination.
            {
                return "That path leads nowhere.";
            }
            p.Location = _destination; //move the player to the new location.
            return $"You head {Name} to {_destination.Name}.\n\n{_destination.FullDescription}"; //return a message about the movement,
        }                                                                                       //including the new location's description.
        
        public virtual bool CanTraverse()
        {
            return _destination != null;
        }
    }
}

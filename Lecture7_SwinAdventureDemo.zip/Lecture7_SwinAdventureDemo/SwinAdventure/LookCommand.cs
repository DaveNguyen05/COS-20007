using System;
//using System.Windows.Input;

namespace SwinAdventure
{
    public class LookCommand : Command //inherited from Command class
    {
        public LookCommand(string[] ids) : base(ids)
        {
        }

        public override string Execute(Player p, string[] text)
        {
            IHaveInventory container = p; //In default if the text only contain 3 keywords, we will know we're looking at the container = p which is the "Player".
            if (text.Length == 3 || text.Length == 5)
            {
                if (text[0].ToLower() == "look") //Everything in the index start from 0, not 1.
                {
                    if (text[1].ToLower() == "at")
                    {
                        if (text.Length == 5)                                    //If the text is longer than 5 keywords then the container might no longer be "p"
                        {                                                      //We'll need to retrieve it with another method, in this case it's "FetchContainer".
                            if (text[3].ToLower() == "in")                    //Where the "FetchContainer" will be the new method that will be developed.
                            {                                                //"FetchContainer" will take in the current obj ("p"), then it will pass through the container ID,
                                container = FetchContainer(p, text[4].ToLower()); //and the container ID should be the keyword of the last index (4), because it's the last container identifier.
                                if (container is null)
                                {
                                    return "I can't find the" + text[4];
                                }
                            }   
                            else                                                            
                            {                                                               
                                return "What do you want to look in?";                      
                            }
                        } //If it can retrieve the container then it can be executed, otherwise by default it's the current player.
                        return LookAtIn(text[2].ToLower(), container); //"LookAtIn" is a method where it will locate the text at index 2.
                    }                                                         //In this case the index 2 is the "bag" text.
                    else                                                      //And retrieve with the current container.
                    {
                        return "What do you want to look at?";
                    }
                }
                else
                {
                    return "Error in look input";
                }
            }
            else
            {
                return "I don't know how to look like that";
            }
        }

        private IHaveInventory FetchContainer(Player p, string containerId) 
        {
            GameObject obj = p.Locate(containerId);
            if (obj == null)
            {
                return null;
            }
            else
            {
                IHaveInventory container = obj as IHaveInventory; //Trying to convert the Object as IHaveInventory.
                return container;
            }
        }

        private string LookAtIn(string thingId, IHaveInventory container)
        {
            GameObject currentItem = container.Locate(thingId); //When it locates the thingID, it will return the "GameObject".
            if (currentItem == null) //Check the current item to see if it's null or not.
            {
                return "The Item" + thingId + " is not available";
            }
            else
            { 
                return currentItem.FullDescription;
            }
        }
    }
}

